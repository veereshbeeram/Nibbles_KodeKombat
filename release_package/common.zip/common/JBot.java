import client.*;

public class JBot extends Bot{

	public JBot(String a, int b){
		super(a,b);	
	}
	
	public void game(int size){
		int mynumber;
		int[] myposition;
		int[][] board;
		try{			
			mynumber = getMyNumber();
			while(true){
				board = getBoard();
				myposition = getMyPosition();
				move();
				shoot();
				/* The above lines inside while loop are sample lines */
				/* You are required to implement your code here */	
			}
		}
		catch(Exception e){
			System.out.println(e.toString());
		}
	}
	
	public static void main(String args[]){
		if(args.length < 2){
			System.out.println("Format of Arguments: client_ip client_port");
			System.exit(0);
		}   
		JBot mybot =  new JBot(args[0],Integer.parseInt(args[1]));
		mybot.game(mybot.size);
	}

public int x,y,friend,team,otherteam,other1,other2,mynumber,myposition[];	
public int[][] board;
}