#!/bin/sh
gnome-terminal -x java -jar client.jar localhost 4000 4001
gnome-terminal -x java -jar client.jar localhost 4000 4002
