#!/bin/sh
gnome-terminal -x java -cp ".:./client.jar" JBot localhost 4001
gnome-terminal -x java -cp ".:./client.jar" JBot localhost 4001
gnome-terminal -x java -cp ".:./client.jar" JBot localhost 4002
gnome-terminal -x java -cp ".:./client.jar" JBot localhost 4002
