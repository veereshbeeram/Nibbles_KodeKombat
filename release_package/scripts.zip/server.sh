#!/bin/sh
gnome-terminal -x java -jar server.jar 11 out 4000
