#!/bin/sh
gnome-terminal -x java -Djava.library.path="." -cp ".:./client.jar" CBot localhost 4001
gnome-terminal -x java -Djava.library.path="." -cp ".:./client.jar" CBot localhost 4001
gnome-terminal -x java -Djava.library.path="." -cp ".:./client.jar" CBot localhost 4002
gnome-terminal -x java -Djava.library.path="." -cp ".:./client.jar" CBot localhost 4002
